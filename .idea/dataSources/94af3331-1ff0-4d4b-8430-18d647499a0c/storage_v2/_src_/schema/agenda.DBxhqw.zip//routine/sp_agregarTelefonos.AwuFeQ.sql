create
    definer = root@localhost procedure sp_agregarTelefonos(IN idPersona int, IN noTelefono int)
begin
	start transaction;
		insert into telefono(telefono.idPersona, telefono.noTelefono) values (idPersona, noTelefono);
    commit;
end;

