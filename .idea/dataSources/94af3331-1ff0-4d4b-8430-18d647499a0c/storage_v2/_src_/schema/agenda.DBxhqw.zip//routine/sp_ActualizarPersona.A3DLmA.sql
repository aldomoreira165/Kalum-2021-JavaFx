create
    definer = root@localhost procedure sp_ActualizarPersona(IN idPersona int, IN nombre varchar(20),
                                                            IN apellido varchar(20), IN edad int)
begin
	start transaction; 
		update persona
        set persona.nombre = nombre, persona.apellido = apellido, persona.edad = edad
        where persona.idPersona = idPersona;
    commit; 
end;

