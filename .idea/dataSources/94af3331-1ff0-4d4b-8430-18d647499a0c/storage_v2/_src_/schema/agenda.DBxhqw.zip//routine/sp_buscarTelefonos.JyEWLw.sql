create
    definer = root@localhost procedure sp_buscarTelefonos(IN idTelefono int)
begin
	select * from telefono where telefono.idTelefono = idTelefono;
end;

