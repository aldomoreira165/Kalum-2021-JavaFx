create
    definer = root@localhost procedure sp_actualizarTelefono(IN idTelefono int, IN idPersona int, IN noTelefono int)
begin
	start transaction;
		update telefono
        set telefono.idPersona = idPersona, telefono.noTelefono = noTelefono
        where telefono.idTelefono = idTelefono;
    commit;
 end;

