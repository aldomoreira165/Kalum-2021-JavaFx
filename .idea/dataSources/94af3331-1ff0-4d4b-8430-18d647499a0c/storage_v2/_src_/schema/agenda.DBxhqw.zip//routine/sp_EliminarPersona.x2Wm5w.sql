create
    definer = root@localhost procedure sp_EliminarPersona(IN idPersona int)
begin
		start transaction;
			delete from persona
            where persona.idPersona = idPersona;
        commit;
    end;

