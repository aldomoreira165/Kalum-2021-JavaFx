create
    definer = root@localhost procedure sp_eliminarTelefonos(IN idTelefono int)
begin
start transaction;
	delete from telefono where telefono.idTelefono = idTelefono;
commit;
end;

