create
    definer = root@localhost procedure sp_BuscarPersona(IN idPersona int)
begin
		select * from persona
        where persona.idPersona = idPersona;
    end;

