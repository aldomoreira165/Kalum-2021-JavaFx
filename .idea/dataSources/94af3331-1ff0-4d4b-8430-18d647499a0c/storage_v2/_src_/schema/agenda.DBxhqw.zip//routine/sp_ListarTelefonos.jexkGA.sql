create
    definer = root@localhost procedure sp_ListarTelefonos()
begin
		select * from telefono;
    end;

