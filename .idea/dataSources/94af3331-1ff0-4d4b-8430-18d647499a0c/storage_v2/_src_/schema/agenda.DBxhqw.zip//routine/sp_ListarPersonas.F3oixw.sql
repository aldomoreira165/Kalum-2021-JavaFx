create
    definer = root@localhost procedure sp_ListarPersonas()
begin
    -- Creamos un SP (StoreProcedure) para listar personas
		select * from persona;
    end;

