create definer = root@localhost view vw_listarpersonas as
select `agenda`.`persona`.`idPersona` AS `idPersona`,
       `agenda`.`persona`.`nombre`    AS `nombre`,
       `agenda`.`persona`.`apellido`  AS `apellido`,
       `agenda`.`persona`.`edad`      AS `edad`
from `agenda`.`persona`;

