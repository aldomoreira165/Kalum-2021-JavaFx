create
    definer = root@localhost procedure sp_Autenticar(IN _username varchar(64), IN _password varchar(128))
BEGIN
    select u.id,
           u.username,
           u.password,
           u.enabled,
           u.nombres,
           u.apellidos,
           u.email,
        u.direccion,
           u.telefono
from usuario_app u where u.username = _username and u.password = md5(_password);
end;

