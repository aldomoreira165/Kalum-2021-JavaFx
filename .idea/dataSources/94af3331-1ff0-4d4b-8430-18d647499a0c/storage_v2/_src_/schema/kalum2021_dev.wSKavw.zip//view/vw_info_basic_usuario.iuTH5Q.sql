create definer = root@localhost view vw_info_basic_usuario as
select `kalum2021_dev`.`usuario_app`.`id`        AS `id`,
       `kalum2021_dev`.`usuario_app`.`username`  AS `username`,
       `kalum2021_dev`.`usuario_app`.`password`  AS `password`,
       `kalum2021_dev`.`usuario_app`.`enabled`   AS `enabled`,
       `kalum2021_dev`.`usuario_app`.`apellidos` AS `apellidos`,
       `kalum2021_dev`.`usuario_app`.`nombres`   AS `nombres`,
       `kalum2021_dev`.`usuario_app`.`email`     AS `email`
from `kalum2021_dev`.`usuario_app`;

